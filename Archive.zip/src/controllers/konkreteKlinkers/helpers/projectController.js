import mongoose from 'mongoose';
import { asyncHandler } from '../../../utils/asyncHandler.js';
import { ApiError } from '../../utils/ApiError.js';
import { ApiResponse } from '../../utils/apiResponse.js';
import { Project } from '../../../models/konkreteKlinkers/helpers/project.model.js';
import { Client } from '../../../models/konkreteKlinkers/helpers/client.model.js';
import Joi from 'joi';

// Create a new project
const createProject = asyncHandler(async (req, res, next) => {
    console.log("Project creation request:", req.body);

    if (!req.user || !req.user._id) {
        return next(new ApiError(401, "Unauthorized. User must be logged in."));
    }

    // Validation schema
    const projectSchema = Joi.object({
        name: Joi.string().required().messages({ 'string.empty': 'Project Name is required' }),
        client: Joi.string().required().messages({ 'string.empty': 'Client ID is required' }),
    });

    const { error, value } = projectSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, 'Validation failed for project creation', error.details));
    }

    const { name, client } = value;

    if (!mongoose.Types.ObjectId.isValid(client)) {
        return next(new ApiError(400, `Provided Client ID (${client}) is not a valid ObjectId`));
    }

    // Check if client exists
    const existingClient = await Client.findById(client);
    if (!existingClient) {
        return next(new ApiError(404, 'No client found with the given ID'));
    }

    // Assign logged-in user's ObjectId as `created_by`
    const created_by = req.user._id;

    const project = await Project.create({ name, client, created_by });

    return res.status(201).json(new ApiResponse(201, project, 'Project created successfully'));
});

// Update a project
const updateProject = asyncHandler(async (req, res, next) => {
    const projectSchema = Joi.object({
        name: Joi.string().optional().messages({ 'string.empty': 'Project Name cannot be empty' }),
        client: Joi.string().optional().messages({ 'string.empty': 'Client ID cannot be empty' }),
    });

    const { error, value } = projectSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, 'Validation failed for project update', error.details));
    }

    const projectId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(projectId)) {
        return next(new ApiError(400, `Provided Project ID (${projectId}) is not a valid ObjectId`));
    }

    if (value.client && !mongoose.Types.ObjectId.isValid(value.client)) {
        return next(new ApiError(400, `Provided Client ID (${value.client}) is not a valid ObjectId`));
    }

    const updateData = {};
    if (value.name) updateData.name = value.name;
    if (value.client) updateData.client = value.client;

    const project = await Project.findByIdAndUpdate(projectId, updateData, { new: true });

    if (!project) {
        return next(new ApiError(404, 'No project found with the given ID'));
    }

    return res.status(200).json(new ApiResponse(200, project, 'Project updated successfully'));
});

// Fetch all projects
const getAllProjects = asyncHandler(async (req, res, next) => {
    const projects = await Project.find()
        .populate('client', 'name address') // Fetch Client details
        .populate('created_by', 'name email'); // Fetch User details who created the project

    if (!projects || projects.length === 0) {
        return next(new ApiError(404, 'No projects available'));
    }

    return res.status(200).json(new ApiResponse(200, projects, 'Projects fetched successfully'));
});

// Fetch project by ID
const getProjectById = asyncHandler(async (req, res, next) => {
    const projectId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(projectId)) {
        return next(new ApiError(400, `Provided Project ID (${projectId}) is not a valid ObjectId`));
    }

    const project = await Project.findById(projectId)
        .populate('client', 'name address') // Fetch Client details
        .populate('created_by', 'name email'); // Fetch User details who created the project

    if (!project) {
        return next(new ApiError(404, 'No project found with the given ID'));
    }

    return res.status(200).json(new ApiResponse(200, project, 'Project fetched successfully'));
});

export { createProject, updateProject, getAllProjects, getProjectById };
