// import { asyncHandler } from '../../../utils/asyncHandler';
import mongoose from 'mongoose';
import { asyncHandler } from '../../../utils/asyncHandler.js';
import { ApiError } from "../../../utils/ApiError.js";

import { ApiResponse } from '../../../utils/apiResponse.js';
import { Client } from '../../../models/konkreteKlinkers/helpers/client.model.js';
import Joi from 'joi';

//Create a client
const createClient = asyncHandler(async (req, res, next) => {
  console.log("Client creation request:", req.body);

  // Validation schema
  const clientSchema = Joi.object({
      name: Joi.string().required().messages({ 'string.empty': 'Name is required' }),
      address: Joi.string().required().messages({ 'string.empty': 'Address is required' }),
      created_by: Joi.string().required().messages({ 'string.empty': 'User ID is required' }),
  });

  const { error, value } = clientSchema.validate(req.body, { abortEarly: false });
  if (error) {
      return next(new ApiError(400, 'Validation failed for client creation', error.details));
  }

  const { name, address, created_by } = value;

  if (!mongoose.Types.ObjectId.isValid(created_by)) {
      return next(new ApiError(400, `Provided User ID (${created_by}) is not a valid ObjectId`));
  }

  const client = await Client.create({ name, address, created_by });

  return res.status(201).json(new ApiResponse(201, client, 'Client created successfully'));
});

// Edit a client
const updateClient = asyncHandler(async (req, res, next) => {
  const clientSchema = Joi.object({
      name: Joi.string().optional().messages({ 'string.empty': 'Name is required' }),
      address: Joi.string().optional().messages({ 'string.empty': 'Address is required' }),
      created_by: Joi.string().optional().messages({ 'string.empty': 'User ID cannot be empty' }),
  });

  const { error, value } = clientSchema.validate(req.body, { abortEarly: false });
  if (error) {
      return next(new ApiError(400, 'Validation failed for client update', error.details));
  }

  const clientId = req.params.id;
  if (!mongoose.Types.ObjectId.isValid(clientId)) {
      return next(new ApiError(400, `Provided Client ID (${clientId}) is not a valid ObjectId`));
  }

  if (value.created_by && !mongoose.Types.ObjectId.isValid(value.created_by)) {
      return next(new ApiError(400, `Provided User ID (${value.created_by}) is not a valid ObjectId`));
  }

  const updateData = {};
  if (value.name) updateData.name = value.name;
  if (value.address) updateData.address = value.address;
  if (value.created_by) updateData.created_by = value.created_by;

  const client = await Client.findByIdAndUpdate(clientId, updateData, { new: true });

  if (!client) {
      return next(new ApiError(404, 'No client found with the given ID'));
  }

  return res.status(200).json(new ApiResponse(200, client, 'Client updated successfully'));
});
// Fetch all clients
const getAllClients = asyncHandler(async (req, res, next) => {
  const clients = await Client.find().populate('created_by', 'name email');

  if (!clients || clients.length === 0) {
      return next(new ApiError(404, 'No clients available'));
  }

  return res.status(200).json(new ApiResponse(200, clients, 'Clients fetched successfully'));
});

// Fetch client by ID
const getClientById = asyncHandler(async (req, res, next) => {
  const clientId = req.params.id;
  if (!mongoose.Types.ObjectId.isValid(clientId)) {
      return next(new ApiError(400, `Provided Client ID (${clientId}) is not a valid ObjectId`));
  }

  const client = await Client.findById(clientId).populate('created_by', 'name email');

  if (!client) {
      return next(new ApiError(404, 'No client found with the given ID'));
  }

  return res.status(200).json(new ApiResponse(200, client, 'Client fetched successfully'));
});

export { createClient, updateClient, getAllClients, getClientById };