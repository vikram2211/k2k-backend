import mongoose from "mongoose";
import { asyncHandler } from "../../../utils/asyncHandler.js";
import { ApiError } from "../../../utils/ApiError.js";
import { ApiResponse } from "../../../utils/apiResponse.js";
import { Plant } from "../../../models/konkreteKlinkers/helpers/plant.model.js";
import Joi from "joi";

// Create a new plant
const createPlant = asyncHandler(async (req, res, next) => {
    console.log("Plant creation request:", req.body);

    // Joi validation schema
    const plantSchema = Joi.object({
        plant_code: Joi.string().required().messages({ "string.empty": "Plant code is required" }),
        plant_name: Joi.string().required().messages({ "string.empty": "Plant name is required" }),
    });

    const { error, value } = plantSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for plant creation", error.details));
    }

    const { plant_code, plant_name } = value;

    // Ensure `created_by` is taken from the logged-in user
    const created_by = req.user._id;

    const plant = await Plant.create({ plant_code, plant_name, created_by });

    return res.status(201).json(new ApiResponse(201, plant, "Plant created successfully"));
});

// Update a plant
const updatePlant = asyncHandler(async (req, res, next) => {
    const plantSchema = Joi.object({
        plant_code: Joi.string().optional(),
        plant_name: Joi.string().optional(),
    });

    const { error, value } = plantSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for plant update", error.details));
    }

    const plantId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(plantId)) {
        return next(new ApiError(400, `Provided Plant ID (${plantId}) is not a valid ObjectId`));
    }

    const updateData = {};
    if (value.plant_code) updateData.plant_code = value.plant_code;
    if (value.plant_name) updateData.plant_name = value.plant_name;

    const plant = await Plant.findByIdAndUpdate(plantId, updateData, { new: true });

    if (!plant) {
        return next(new ApiError(404, "No plant found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, plant, "Plant updated successfully"));
});

// Fetch all plants
const getAllPlants = asyncHandler(async (req, res, next) => {
    const plants = await Plant.find().populate("created_by", "name email");

    if (!plants || plants.length === 0) {
        return next(new ApiError(404, "No plants available"));
    }

    return res.status(200).json(new ApiResponse(200, plants, "Plants fetched successfully"));
});

// Fetch plant by ID
const getPlantById = asyncHandler(async (req, res, next) => {
    const plantId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(plantId)) {
        return next(new ApiError(400, `Provided Plant ID (${plantId}) is not a valid ObjectId`));
    }

    const plant = await Plant.findById(plantId).populate("created_by", "name email");

    if (!plant) {
        return next(new ApiError(404, "No plant found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, plant, "Plant fetched successfully"));
});

export { createPlant, updatePlant, getAllPlants, getPlantById };
