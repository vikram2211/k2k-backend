import mongoose from "mongoose";
import { asyncHandler } from "../../../utils/asyncHandler.js";
import { ApiError } from "../../../utils/ApiError.js";
import { ApiResponse } from "../../../utils/apiResponse.js";
import { Machine } from "../../../models/konkreteKlinkers/helpers/machine.model.js";
import Joi from "joi";

// Create a new machine
const createMachine = asyncHandler(async (req, res, next) => {
    console.log("Machine creation request:", req.body);

    // Joi validation schema
    const machineSchema = Joi.object({
        client_id: Joi.string().required().messages({ "string.empty": "Client ID is required" }),
        name: Joi.string().required().messages({ "string.empty": "Machine name is required" }),
    });

    const { error, value } = machineSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for machine creation", error.details));
    }

    const { client_id, name } = value;

    // Ensure `created_by` is taken from the logged-in user
    const created_by = req.user._id;

    // Validate `client_id` as a valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(client_id)) {
        return next(new ApiError(400, `Provided Client ID (${client_id}) is not a valid ObjectId`));
    }

    const machine = await Machine.create({ client_id, name, created_by });

    return res.status(201).json(new ApiResponse(201, machine, "Machine created successfully"));
});

// Update a machine
const updateMachine = asyncHandler(async (req, res, next) => {
    const machineSchema = Joi.object({
        client_id: Joi.string().optional(),
        name: Joi.string().optional(),
    });

    const { error, value } = machineSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for machine update", error.details));
    }

    const machineId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(machineId)) {
        return next(new ApiError(400, `Provided Machine ID (${machineId}) is not a valid ObjectId`));
    }

    const updateData = {};
    if (value.client_id) {
        if (!mongoose.Types.ObjectId.isValid(value.client_id)) {
            return next(new ApiError(400, `Provided Client ID (${value.client_id}) is not a valid ObjectId`));
        }
        updateData.client_id = value.client_id;
    }
    if (value.name) updateData.name = value.name;

    const machine = await Machine.findByIdAndUpdate(machineId, updateData, { new: true });

    if (!machine) {
        return next(new ApiError(404, "No machine found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, machine, "Machine updated successfully"));
});

// Fetch all machines
const getAllMachines = asyncHandler(async (req, res, next) => {
    const machines = await Machine.find().populate("client_id", "name").populate("created_by", "name email");

    if (!machines || machines.length === 0) {
        return next(new ApiError(404, "No machines available"));
    }

    return res.status(200).json(new ApiResponse(200, machines, "Machines fetched successfully"));
});

// Fetch machine by ID
const getMachineById = asyncHandler(async (req, res, next) => {
    const machineId = req.params.id;
    if (!mongoose.Types.ObjectId.isValid(machineId)) {
        return next(new ApiError(400, `Provided Machine ID (${machineId}) is not a valid ObjectId`));
    }

    const machine = await Machine.findById(machineId).populate("client_id", "name").populate("created_by", "name email");

    if (!machine) {
        return next(new ApiError(404, "No machine found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, machine, "Machine fetched successfully"));
});

export { createMachine, updateMachine, getAllMachines, getMachineById };
