import mongoose from 'mongoose';
import { asyncHandler } from '../../../utils/asyncHandler.js';
import { ApiError } from '../../../utils/ApiError.js';
import { ApiResponse } from '../../../utils/apiResponse.js';
import { Dispatch } from '../../../models/konkreteKlinkers/dispatch.model.js';
import { Packing } from '../../../models/konkreteKlinkers/packing.model.js';
import { WorkOrder } from '../../../models/konkreteKlinkers/workOrder.model.js';
import Joi from 'joi';

// ✅ Validation Schema for Dispatch
const dispatchSchema = Joi.object({
    work_order: Joi.string().required().messages({ 'string.empty': 'Work Order ID is required' }),
    invoice_or_sto: Joi.string().required().messages({ 'string.empty': 'Invoice/STO is required' }),
    vehicle_number: Joi.string().required().messages({ 'string.empty': 'Vehicle number is required' }),
    qr_codes: Joi.array().items(Joi.string()).required().messages({ 'array.empty': 'At least one QR code is required' }),
});

// ✅ Create Dispatch Entry
export const createDispatch = asyncHandler(async (req, res, next) => {
    console.log('Dispatch creation request:', req.body);

    // Validate request body
    const { error, value } = dispatchSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, 'Validation failed for dispatch creation', error.details));
    }

    const { work_order, invoice_or_sto, vehicle_number, qr_codes } = value;
    const userId = req.user.id; // Logged-in user creating the dispatch

    // Check if work order is valid
    if (!mongoose.Types.ObjectId.isValid(work_order)) {
        return next(new ApiError(400, `Invalid Work Order ID: ${work_order}`));
    }

    // ✅ Fetch Packing Entries Based on Scanned QR Codes
    const packingEntries = await Packing.find({ qr_code: { $in: qr_codes } });

    if (!packingEntries || packingEntries.length === 0) {
        return next(new ApiError(404, 'No packing entries found for scanned QR codes'));
    }

    // ✅ Prepare Products Array for Dispatch
    const products = packingEntries.map(packing => ({
        product_id: packing.product,
        product_name: packing.product_name, // Optional, can be derived from Product model
        dispatch_quantity: packing.product_quantity,
        bundle_size: packing.bundle_size,
    }));

    // ✅ Create Dispatch Entry
    const dispatchEntry = await Dispatch.create({
        work_order,
        packing_ids: packingEntries.map(p => p._id),
        products,
        invoice_or_sto,
        qr_codes,
        vehicle_number,
        created_by: userId,
    });

    return res.status(201).json(new ApiResponse(201, dispatchEntry, 'Dispatch created successfully'));
});

// ✅ Get All Dispatch Entries
export const getAllDispatches = asyncHandler(async (req, res, next) => {
    const dispatches = await Dispatch.find()
        .populate('work_order', 'order_number')
        .populate('packing_ids')
        .populate('created_by', 'name');

    if (!dispatches || dispatches.length === 0) {
        return next(new ApiError(404, 'No dispatches found'));
    }

    return res.status(200).json(new ApiResponse(200, dispatches, 'Dispatch records fetched successfully'));
});

// ✅ Get Dispatch by ID
export const getDispatchById = asyncHandler(async (req, res, next) => {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return next(new ApiError(400, `Invalid Dispatch ID: ${id}`));
    }

    const dispatch = await Dispatch.findById(id)
        .populate('work_order', 'order_number')
        .populate('packing_ids')
        .populate('created_by', 'name');

    if (!dispatch) {
        return next(new ApiError(404, 'Dispatch not found'));
    }

    return res.status(200).json(new ApiResponse(200, dispatch, 'Dispatch details fetched successfully'));
});

// ✅ Update Dispatch (Status Change)
export const updateDispatchStatus = asyncHandler(async (req, res, next) => {
    const { id } = req.params;
    const { status } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id)) {
        return next(new ApiError(400, `Invalid Dispatch ID: ${id}`));
    }

    if (!['Approved', 'Rejected'].includes(status)) {
        return next(new ApiError(400, 'Invalid status value'));
    }

    const updatedDispatch = await Dispatch.findByIdAndUpdate(id, { status }, { new: true });

    if (!updatedDispatch) {
        return next(new ApiError(404, 'Dispatch not found'));
    }

    return res.status(200).json(new ApiResponse(200, updatedDispatch, `Dispatch status updated to ${status}`));
});
