// controllers/workOrderController.js
import { WorkOrder } from '../../models/konkreteKlinkers/workOrder.model';
import { z } from 'zod';

// Define Zod schema for validation
const createWorkOrderSchema = z.object({
  client_id: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid Client ID"),
  project_id: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid Project ID"),
  work_order_number: z.string().min(1, "Work Order Number is required"),
  date: z.string().refine((date) => !isNaN(Date.parse(date)), "Invalid Date"),
  buffer_stock: z.boolean().optional(),
  products: z.array(z.object({
    product_id: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid Product ID"),
    uom: z.string().min(1, "Unit of Measurement is required"),
    po_quantity: z.number().min(1, "PO Quantity must be at least 1"),
    plant_code: z.string().min(1, "Plant Code is required"),
    delivery_date: z.string().refine((date) => date === "" || !isNaN(Date.parse(date)), "Invalid Delivery Date").optional(),
  })).min(1, "At least one product is required"),
  files: z.array(z.object({
    file_name: z.string().min(1, "File Name is required"),
    file_url: z.string().url("Invalid File URL"),
  })).min(1, "At least one file is required"),
  status: z.enum(["Pending", "In Progress", "Completed", "Cancelled"]).optional(),
  created_by: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid User ID"),
  updated_by: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid User ID"),
  job_orders: z.array(z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid JobOrder ID")).optional(),
});

export const createWorkOrder = async (req, res) => {
  try {
    // Validate request data
    const validatedData = createWorkOrderSchema.parse(req.body);

    // Convert date strings to Date objects
    validatedData.date = new Date(validatedData.date);
    validatedData.products = validatedData.products.map(product => ({
      ...product,
      delivery_date: product.delivery_date ? new Date(product.delivery_date) : undefined,
    }));

    // Create and save the WorkOrder
    const workOrder = new WorkOrder(validatedData);
    await workOrder.save();

    res.status(201).json({ success: true, data: workOrder });
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Handle Zod validation errors
      return res.status(400).json({
        success: false,
        errors: error.errors.map(err => ({
          field: err.path.join('.'),
          message: err.message,
        })),
      });
    }

    // Handle Mongoose validation errors
    if (error.name === 'ValidationError') {
      const formattedErrors = Object.values(error.errors).map(err => ({
        field: err.path,
        message: err.message,
      }));
      return res.status(400).json({
        success: false,
        errors: formattedErrors,
      });
    }

    // Handle other errors
    console.error("Error creating WorkOrder:", error);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};
