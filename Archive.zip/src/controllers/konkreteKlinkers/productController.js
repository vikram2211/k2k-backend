import mongoose from "mongoose";
import { asyncHandler } from "../../../utils/asyncHandler.js";
import { ApiError } from "../../../utils/ApiError.js";
import { ApiResponse } from "../../../utils/apiResponse.js";
import { Product } from "../../../models/konkreteKlinkers/helpers/product.model.js";
import Joi from "joi";

// **Validation Schema**
const productSchema = Joi.object({
    material_code: Joi.string().required().messages({
        "string.empty": "Material Code is required",
    }),
    description: Joi.string().required().messages({
        "string.empty": "Description is required",
    }),
    uom: Joi.string().valid("SQ. Metre", "Nos").required().messages({
        "any.only": "UOM must be either 'SQ. Metre' or 'Nos'",
        "string.empty": "UOM is required",
    }),
    length: Joi.number().when("uom", {
        is: "SQ. Metre",
        then: Joi.number().required().messages({
            "number.base": "Length must be a number",
            "any.required": "Length is required for UOM 'SQ. Metre'",
        }),
        otherwise: Joi.optional(),
    }),
    breadth: Joi.number().when("uom", {
        is: "SQ. Metre",
        then: Joi.number().required().messages({
            "number.base": "Breadth must be a number",
            "any.required": "Breadth is required for UOM 'SQ. Metre'",
        }),
        otherwise: Joi.optional(),
    }),
    no_of_pieces_per_punch: Joi.number().required().messages({
        "number.base": "Number of pieces per punch must be a number",
        "any.required": "Number of pieces per punch is required",
    }),
    qty_in_bundle: Joi.number().required().messages({
        "number.base": "Quantity in bundle must be a number",
        "any.required": "Quantity in bundle is required",
    }),
    qty_in_nos_per_bundle: Joi.number().required().messages({
        "number.base": "Quantity in NOS per bundle must be a number",
        "any.required": "Quantity in NOS per bundle is required",
    }),
    status: Joi.string().valid("Active", "Inactive").default("Active"),
});

// **Create Product**
const createProduct = asyncHandler(async (req, res, next) => {
    console.log("Product creation request:", req.body);

    // Validate request body
    const { error, value } = productSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for product creation", error.details));
    }

    const { material_code, description, uom, length, breadth, no_of_pieces_per_punch, qty_in_bundle, qty_in_nos_per_bundle, status } = value;

    // Get logged-in user ID (from authentication middleware)
    const created_by = req.user._id;

    const newProduct = await Product.create({
        material_code,
        description,
        uom,
        length,
        breadth,
        no_of_pieces_per_punch,
        qty_in_bundle,
        qty_in_nos_per_bundle,
        created_by,
        status,
    });

    return res.status(201).json(new ApiResponse(201, newProduct, "Product created successfully"));
});

// **Get All Products**
const getAllProducts = asyncHandler(async (req, res, next) => {
    const products = await Product.find().populate("created_by", "name email");

    if (!products || products.length === 0) {
        return next(new ApiError(404, "No products available"));
    }

    return res.status(200).json(new ApiResponse(200, products, "Products fetched successfully"));
});

// **Get Product by ID**
const getProductById = asyncHandler(async (req, res, next) => {
    const productId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
        return next(new ApiError(400, `Provided Product ID (${productId}) is not a valid ObjectId`));
    }

    const product = await Product.findById(productId).populate("created_by", "name email");

    if (!product) {
        return next(new ApiError(404, "No product found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, product, "Product fetched successfully"));
});

// **Update Product**
const updateProduct = asyncHandler(async (req, res, next) => {
    const productId = req.params.id;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
        return next(new ApiError(400, `Provided Product ID (${productId}) is not a valid ObjectId`));
    }

    const { error, value } = productSchema.validate(req.body, { abortEarly: false });
    if (error) {
        return next(new ApiError(400, "Validation failed for product update", error.details));
    }

    const updatedProduct = await Product.findByIdAndUpdate(productId, value, { new: true });

    if (!updatedProduct) {
        return next(new ApiError(404, "No product found with the given ID"));
    }

    return res.status(200).json(new ApiResponse(200, updatedProduct, "Product updated successfully"));
});

export { createProduct, getAllProducts, getProductById, updateProduct };
