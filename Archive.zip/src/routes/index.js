import { Router } from 'express';
import userRouter from './user.routes.js';
import clientRouter from './client.routes.js';

const router = Router();

// Register routes
router.use('/users', userRouter);

//the routes should be a/c to the company type, so that multiple companies can be added.
router.use('/konkreteKlinkers', clientRouter);

//routes a/c to the employee permissions. 
//either the employee can have the access to the individual CRUD operations (more chances this will be implemented ~ full control , create any type of user in the future and use. submadmin,qc check, inventory check , etc.. no difference among each other.)or
// according to the process which means in each continuous checks page can be added. and if its done for multiple employees .(complex)


export default router;
