export const DB_NAME = 'k2k-iot';
